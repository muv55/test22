from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    RecipeViewSet, TagViewSet, UserViewSet,
    IngredientViewSet, LoginViewSet, SubscribeViewSet,
    FavoriteViewSet, logout, password_change
)

app_name = 'api'

router = DefaultRouter()

router.register(r'users', UserViewSet, basename='users')
router.register(r'tags', TagViewSet, basename='tags')
router.register(r'recipes', RecipeViewSet, basename='recipes')
router.register(r'ingredients', IngredientViewSet, basename='ingredients')
router.register(r'auth/token/login', LoginViewSet, basename='login')
router.register(
    r'users/subscriptions',
    SubscribeViewSet,
    basename='subscriptions'
)

urlpatterns = [
    path('auth/token/logout/', logout, name='token_logout'),
    path('users/set_password/', password_change, name='set_password'),
    path(
        'users/me/',
        UserViewSet.as_view({'get': 'me'}),
        name='user_me'
    ),
    path(
        'recipes/<int:pk>/favorite/',
        FavoriteViewSet.as_view({'post': 'add_favorite'}),
        name='recipes-add-favorite'
    ),
    path(
        'recipes/<int:pk>/shopping_cart/',
        RecipeViewSet.as_view({'post': 'add_to_shopping_cart'}),
        name='recipes-add-to-shopping-cart'
    ),
    path(
        'users/<int:pk>/subscribe/',
        UserViewSet.as_view({'post': 'subscribe'}),
        name='users-subscribe'
    ),
    path('', include(router.urls)),
]
