from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.db.models import Sum
from rest_framework.validators import UniqueTogetherValidator
from drf_extra_fields.fields import Base64ImageField
from django.db.models import Count

from recipes.models import (Recipe, Tag, Favorite, ShoppingList,
                            Ingredient, RecipeIngredient)
from users.models import Subscribe
from foodgram.settings import MAX_LEN_CHAR, MAX_LEN_EMAIL

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    """Сериализатор для модели User"""
    is_subscribe = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            'id',
            'username',
            'email',
            'first_name',
            'last_name',
            'is_subscribe'
        )

    def get_is_subscribe(self, obj):
        """
        Возвращает True, если пользователь подписан на автора, иначе False.
        """
        user = self.context.get('request').user
        if user.is_anonymous:
            return False
        return obj.follow.filter(user=user).exists()


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = '__all__'

    def create(self, validated_data):
        """Создает нового пользователя на основе переданных данных."""
        username = validated_data['username']
        email = validated_data['email']
        password = validated_data['password']

        if User.objects.filter(username=username).exists():
            raise serializers.ValidationError(
                'Ой! Пользователь с таким именем уже существует!'
            )
        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError(
                'Упс! Пользователь с таким email уже существует!')

        user = User.objects.create_user(username=username, email=email,
                                        password=password)
        return user


class UserLoginSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True, max_length=MAX_LEN_EMAIL)
    password = serializers.CharField(required=True, max_length=MAX_LEN_CHAR)


class TagSerializer(serializers.ModelSerializer):
    """Сериализатор для модели Tag"""

    class Meta:
        model = Tag
        fields = '__all__'


class ShoppingListSerializer(serializers.ModelSerializer):
    """Сериализатор для модели ShoppingList"""
    ingredient = serializers.SerializerMethodField()

    class Meta:
        model = ShoppingList
        fields = ('id', 'recipe', 'ingredient')

    def get_ingredient(self, obj):
        """Получает и сериализует ингредиенты для объекта ShoppingList."""
        queryset = self.get_queryset(obj)
        serialized_queryset = IngredientSerializer(
            instance=queryset,
            many=True
        )
        result = {}
        for ingredient in serialized_queryset.data:
            amount = float(ingredient['amount'])
            if ingredient['name'] in result:
                result[ingredient['name']]['amount'] += amount
            else:
                result[ingredient['name']] = {
                    'measurement_unit': ingredient['measurement_unit'],
                    'amount': amount
                }
        return result

    def get_queryset(self, obj):
        """Получает QuerySet ингредиентов для объекта ShoppingList."""
        queryset = Ingredient.objects.filter(
            recipe__list__user=obj.user,
            recipe__list=obj
        )
        queryset = queryset.annotate(amount=Sum(
            'recipeingredient__amount'
        ))
        queryset = queryset.values(
            'name',
            'measurement_unit',
            'amount'
        )
        return queryset


class IngredientSerializer(serializers.ModelSerializer):
    """Сериализатор для модели Ingredient"""

    class Meta:
        model = Ingredient
        fields = '__all__'


class RecipeIngredientSerializer(serializers.ModelSerializer):
    """Сериализатор для модели RecipeIngredient"""
    id = serializers.ReadOnlyField(source='ingredient.id')
    ingredient = serializers.ReadOnlyField(source='ingredient.name')
    measurement_unit = serializers.ReadOnlyField(
        source='ingredient.measurement_unit')
    amount = serializers.ReadOnlyField()
    recipe = serializers.ReadOnlyField(source='recipe.id')

    class Meta:
        model = RecipeIngredient
        fields = '__all__'
        validators = [
            UniqueTogetherValidator(
                queryset=RecipeIngredient.objects.all(),
                fields=['ingredient', 'recipe']
            )
        ]


class RecipeSerializer(serializers.ModelSerializer):
    """Сериализатор для модели Recipe"""
    author = UserSerializer(read_only=True)
    ingredients = RecipeIngredientSerializer(many=True,)
    image = Base64ImageField()
    tags = TagSerializer(many=True, read_only=True)
    recipe = serializers.ReadOnlyField(source='title')
    is_favorite = serializers.SerializerMethodField()
    is_shopping_cart = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = fields = (
            'id',
            'tags',
            'author',
            'recipe',
            'ingredients',
            'is_favorite',
            'is_shopping_cart',
            'title',
            'image',
            'description',
            'cooking_time',
            'pub_date',
        )

    def get_ingredients(self, obj):
        """
        Возвращает сериализованные данные
        по связанным ингредиентам рецепта.
        """
        recipe_ingredients = obj.recipe_ingredients.all()
        serializer = RecipeIngredientSerializer(
            recipe_ingredients,
            many=True
        )
        return serializer.data

    def get_is_favorite(self, obj):
        """
        Проверяет, является ли рецепт избранным
        для текущего пользователя.
        """
        user = self.context['request'].user
        if user.is_authenticated:
            return obj.favorited_by.filter(user=user).exists()
        return False

    def get_is_shopping_cart(self, obj):
        """
        Проверяет, находится ли рецепт в списке покупок
        для текущего пользователя.
        """
        user = self.context['request'].user
        if user.is_authenticated:
            return obj.list.filter(user=user).exists()
        return False

    def create(self, validated_data):
        """Создает новый рецепт."""
        ingredients_data = validated_data.pop('ingredients', [])
        tags_data = validated_data.pop('tags', [])

        recipe = Recipe.objects.create(**validated_data)

        self.add_ingredients(recipe, ingredients_data)

        recipe.tags.set(tags_data)
        return recipe

    def update(self, instance, validated_data):
        """Обновляет существующий рецепт."""
        ingredients_data = validated_data.pop('ingredients', [])
        tags_data = validated_data.pop('tags', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.recipe_ingredients.all().delete()

        self.add_ingredients(instance, ingredients_data)

        instance.tags.set(tags_data)
        instance.save()
        return instance

    def add_ingredients(self, recipe, ingredients_data):
        """Добавляет ингредиенты к рецепту."""
        for ingredient_data in ingredients_data:
            ingredient = Ingredient.objects.get(
                pk=ingredient_data['ingredient']
            )
            RecipeIngredient.objects.create(
                recipe=recipe,
                ingredient=ingredient,
                **ingredient_data
            )


class FavoriteSerializer(serializers.ModelSerializer):
    """Сериализатор для модели Favorite"""
    recipe = RecipeSerializer(read_only=True)

    class Meta:
        model = Favorite
        fields = ('id', 'recipe')

    def to_representation(self, instance):
        """Преобразует объект Favorite."""
        serialized_instance = super().to_representation(instance)
        serialized_instance['user'] = instance.user.id
        return serialized_instance

    def create(self, validated_data):
        """"Создает объект Favorite."""
        user = self.context['request'].user
        recipe = validated_data['recipe']
        favorite = Favorite(user=user, recipe=recipe)
        favorite.save()
        return favorite


class SubscribeSerializer(serializers.ModelSerializer):
    """Сериализатор для модели Subscribe"""
    id = serializers.ReadOnlyField(source='author.id')
    email = serializers.ReadOnlyField(source='author.email')
    username = serializers.ReadOnlyField(source='author.username')
    first_name = serializers.ReadOnlyField(source='author.first_name')
    last_name = serializers.ReadOnlyField(source='author.last_name')
    is_subscribe = serializers.SerializerMethodField()
    recipes = serializers.SerializerMethodField()
    recipes_count = serializers.SerializerMethodField()

    class Meta:
        model = Subscribe
        fields = (
            'email',
            'id',
            'username',
            'first_name',
            'last_name',
            'is_subscribed',
            'recipes',
            'recipes_count',
        )

    def get_is_subscribe(self, obj):
        """Проверяет, подписан ли пользователь на автора."""
        return obj.author.follow.filter(
            user=obj.user
        ).exists()

    def get_username(self, obj):
        """Возвращает имя пользователя автора подписки."""
        return obj.author.username

    def get_recipes(self, obj):
        """
        Возвращает список рецептов автора
        с возможным ограничением по количеству.
        """
        request = self.context.get('request')
        limit = request.GET.get('recipes_limit')

        subscribed_recipes = (
            Subscribe.objects
            .filter(user=obj.author)
            .values_list('author__recipes', flat=True)
        )
        queryset = Recipe.objects.filter(pk__in=subscribed_recipes)

        if limit:
            queryset = queryset[:int(limit)]

        return RecipeSerializer(queryset, many=True).data

    def get_recipes_count(self, obj):
        """Возвращает количество рецептов автора."""
        return obj.author.follow.annotate(
            recipes_count=Count('recipes')).recipes_count


class UserPasswordSerializer(serializers.Serializer):
    """Сериализатор для обновления пароля пользователя."""
    new_password = serializers.CharField(
        max_length=MAX_LEN_CHAR,
        required=True
    )
    current_password = serializers.CharField(
        max_length=MAX_LEN_CHAR,
        required=True
    )

    def validate(self, attrs):
        """Проверка обновленных паролей на соответствие."""
        if attrs['new_password'] == attrs['current_password']:
            raise serializers.ValidationError(
                'Так не пойдет! Новый пароль не может совпадать с текущим!'
            )
        return attrs
