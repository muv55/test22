from rest_framework import status, viewsets
from django.contrib.auth import get_user_model
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.authtoken.models import Token
from rest_framework.generics import get_object_or_404
from rest_framework.decorators import action, api_view
from rest_framework.viewsets import ReadOnlyModelViewSet
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from django.db.models import Sum

from .pagination import CustomPaginator
from users.models import Subscribe
from recipes.models import (Recipe, Tag, Favorite, ShoppingList,
                            Ingredient, RecipeIngredient)
from .serializers import (
    UserSerializer, RecipeSerializer, TagSerializer, FavoriteSerializer,
    ShoppingListSerializer, IngredientSerializer,
    SubscribeSerializer, UserRegistrationSerializer,
    UserLoginSerializer, UserPasswordSerializer
)
from .filters import AuthorTagFilter, IngredientSearchFilter
from foodgram.settings import SHOP_LIST


User = get_user_model()


class UserViewSet(viewsets.ModelViewSet):
    """Представление для получения информации о пользователе."""
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = (AllowAny,)
    paginator_class = CustomPaginator
    lookup_field = 'pk'

    @action(methods=['post'], detail=True, permission_classes=[AllowAny])
    def create_user(self, request):
        """Создает нового пользователя."""
        serializer = UserRegistrationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        response_data = {
            'email': user.email,
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name
        }
        return Response(response_data, status=status.HTTP_201_CREATED)

    @action(methods=['post'], detail=False, permission_classes=[AllowAny])
    def set_password(self, request):
        """Устанавливает пароль для пользователя."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        request.user.set_password(serializer.validated_data['new_password'])
        request.user.save()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(methods=['get', 'post'], detail=True,
            permission_classes=[AllowAny])
    def subscribe(self, request, pk=None):
        """Подписывает текущего пользователя на другого пользователя."""
        user = request.user
        author = get_object_or_404(User, pk=pk)

        if user == author:
            return Response({'errors': 'Ай-ай! '
                            'Нельзя подписаться на самого себя!'},
                            status=status.HTTP_400_BAD_REQUEST)

        if Subscribe.objects.filter(user=user, author=author).exists():
            return Response({'errors': 'Так, кажется, Вы уже подписаны '
                            'на этого пользователя!'},
                            status=status.HTTP_400_BAD_REQUEST)

        subscribe = Subscribe.objects.create(user=user, author=author)
        serializer = SubscribeSerializer(
            subscribe,
            context={'request': request}
        )
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(methods=['delete'], detail=True, permission_classes=[AllowAny])
    def del_subscribe(self, request, pk=None):
        """Отписывает текущего пользователя от другого пользователя."""
        user = request.user
        author = get_object_or_404(User, pk=pk)

        if user == author:
            return Response({'errors': 'Увы! '
                            'Но вы не можете отписываться от самого себя!'},
                            status=status.HTTP_400_BAD_REQUEST)

        subscribe = Subscribe.objects.filter(user=user, author=author)
        if subscribe.exists():
            subscribe.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)

        return Response({'errors': 'Мы проверили, Вы уже отписались!'},
                        status=status.HTTP_400_BAD_REQUEST)

    @action(methods=['get'],
            detail=False, permission_classes=[IsAuthenticated])
    def me(self, request):
        """
        Возвращает информацию о пользователе,
        отправляющем HTTP-запрос на этот view.
        """
        if not request.user.is_authenticated:
            return Response(
                {'detail': 'Пользователь не аутентифицирован!'},
                status=status.HTTP_401_UNAUTHORIZED
            )

        user = self.request.user
        serializer = UserSerializer(user)
        return Response(serializer.data)


class LoginViewSet(viewsets.ModelViewSet):
    """Представление для входа пользователя."""
    queryset = User.objects.all()
    serializer_class = UserLoginSerializer
    permission_classes = (AllowAny,)

    def create(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        user = get_object_or_404(User, email=email)

        if user.check_password(serializer.data['password']):
            token, _ = Token.objects.get_or_create(user=user)
            return Response({'token': token.key}, status=status.HTTP_200_OK)
        return Response(
            {'detail': 'Уупс! Неверный пароль!'},
            status=status.HTTP_400_BAD_REQUEST
        )

    @action(methods=['post'], detail=False, permission_classes=[AllowAny])
    def login(self, request):
        """
        Обрабатывает POST-запросы для аутентификации пользователя.
        Если учетные данные верны, генерируется и возвращается токен доступа.
        """
        serializer = UserLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = get_object_or_404(User, email=serializer.data['email'])

            if user.check_password(serializer.data['password']):
                token = user.auth_token
                if token is None:
                    token = Token.objects.create(user=user)

                return Response(
                    {"auth_token": token.key},
                    status=status.HTTP_201_CREATED
                )
            return Response({'detail': 'Уупс! Неверный пароль!'})
        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )


class RecipeViewSet(viewsets.ModelViewSet):
    """Представление для получения рецептов."""
    queryset = Recipe.objects.all()
    serializer_class = RecipeSerializer
    permission_classes = (AllowAny,)
    pagination_class = CustomPaginator
    filter_class = AuthorTagFilter
    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('author',)
    http_method_names = ['get', 'post', 'patch', 'delete']

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

    @action(detail=True, methods=['post', 'delete'],
            permission_classes=[AllowAny])
    def favorite(self, request, pk):
        """Добавляет или удаляет рецепт из избранного."""
        recipe = get_object_or_404(Recipe, id=pk)
        if request.method == 'POST':
            favorite, created = Favorite.objects.get_or_create(
                user=request.user,
                recipe=recipe
            )
            if created:
                serializer = FavoriteSerializer(favorite)
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)
        elif request.method == 'DELETE':
            favorite = Favorite.objects.filter(
                user=request.user,
                recipe=recipe
            )
            if favorite.exists():
                favorite.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['get'],
            permission_classes=[AllowAny])
    def shopping_cart(self, request, pk):
        """Получает список покупок для рецепта."""
        recipe = get_object_or_404(Recipe, id=pk)
        shopping_list = ShoppingList.objects.filter(
            user=request.user,
            recipe=recipe
        )
        serializer = ShoppingListSerializer(
            shopping_list,
            many=True
        )
        return Response(serializer.data)

    @action(detail=True, methods=['post', 'delete'],
            permission_classes=[AllowAny])
    def add_to_shopping_list(self, request, pk):
        """Добавляет или удаляет рецепт из списка покупок."""
        recipe = get_object_or_404(Recipe, id=pk)
        if request.method == 'POST':
            list, created = ShoppingList.objects.get_or_create(
                user=request.user,
                recipe=recipe
            )
            if created:
                serializer = ShoppingListSerializer(list)
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)
        elif request.method == 'DELETE':
            list = ShoppingList.objects.filter(
                user=request.user,
                recipe=recipe
            )
            if list.exists():
                list.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'],
            permission_classes=[AllowAny])
    def download_shopping_list(self, request):
        """Скачивает список покупок в виде текстового файла."""
        ingredients = (
            RecipeIngredient.objects
            .filter(recipes__list__user=request.user)
            .values('ingredient')
            .annotate(total_amount=Sum('amount'))
            .values_list('ingredient__name', 'total_amount',
                         'ingredient__measurement_unit')
        )
        file_list = []
        for ingredient in ingredients:
            file_list.append('{} - {} {}.'.format(*ingredient))
        file_content = 'Список покупок:\n' + '\n'.join(file_list)
        shopping_list = Response(file_content, content_type='text/plain')
        shopping_list['Content-Disposition'] = (
            f'attachment; filename={SHOP_LIST}'
        )
        return shopping_list


class IngredientViewSet(ReadOnlyModelViewSet):
    """
    Представление для получения списка ингредиентов и
    создания нового ингредиента.
    """
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer
    permission_classes = (AllowAny,)
    pagination_class = CustomPaginator
    filter_backends = (IngredientSearchFilter,)
    search_fields = ('=name',)

    def create(self, request, *args, **kwargs):
        """Создает новый ингредиент."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ingredient = serializer.save()
        return Response(
            self.serializer_class(ingredient).data,
            status=status.HTTP_201_CREATED
        )


class TagViewSet(ReadOnlyModelViewSet):
    """Представление для получения списка рецептов, отмеченных тегом"""
    queryset = Tag.objects.all()
    serializer_class = TagSerializer
    permission_classes = (AllowAny,)


class SubscribeViewSet(viewsets.ModelViewSet):
    """Представление для подписок."""
    serializer_class = SubscribeSerializer
    permission_classes = (IsAuthenticated,)
    pagination_class = CustomPaginator

    def get_queryset(self):
        queryset = User.objects.get(id=self.request.user.id).follower.all()
        return queryset

    def create(self, request):
        """Создает новую подписку."""
        user = request.user
        author_id = request.data.get('author')

        if user.follower.filter(user=user, author_id=author_id).exists():
            return Response({'error': 'Мы проверили! '
                            'Вы уже подписаны на этого пользователя!'},
                            status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(user=user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def destroy(self, request, **kwargs):
        """Удаляет подписку."""
        user = request.user
        subscription = get_object_or_404(
            Subscribe,
            id=kwargs.get('pk'), user=user
        )
        subscription.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class FavoriteViewSet(viewsets.ModelViewSet):
    """Представление для работы с избранными рецептами"""
    serializer_class = FavoriteSerializer
    permission_classes = (AllowAny,)

    def perform_create(self, serializer):
        """Сохраняет избранный рецепт при создании."""
        serializer.save(user=self.request.user)

    def get_queryset(self):
        """
        Возвращает queryset избранных рецептов для текущего пользователя.
        """
        return self.request.user.favorites.all()

    @action(detail=True, methods=['POST'],
            permission_classes=[AllowAny])
    def add_favorite(self, request, pk=None):
        """Добавляет рецепт в избранное."""
        recipe = Recipe.objects.get(pk=pk)
        Favorite.objects.create(user=request.user, recipe=recipe)
        return Response({'detail': 'Успех! Рецепт добавлен в избранное!'},
                        status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['DELETE'],
            permission_classes=[AllowAny])
    def delete_favorite(self, request, pk=None):
        """Удаляет рецепт из избранного."""
        return self.delete_obj(Favorite, request.user, pk)

    def delete_obj(self, model, user, pk):
        """Удаляет рецепт из модели (избранное)."""
        obj = model.objects.filter(user=user, recipe__id=pk)
        if obj.exists():
            obj.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        return Response({
            'errors': 'Ууупс! Рецепт не найден в избранном!'
        }, status=status.HTTP_400_BAD_REQUEST)


class ShoppingListViewSet(viewsets.ModelViewSet):
    """Представление для работы со списком покупок"""
    serializer_class = ShoppingListSerializer
    permission_classes = (AllowAny,)

    def perform_create(self, serializer):
        """Сохраняет список покупок при создании."""
        serializer.save(user=self.request.user)

    def get_queryset(self):
        """Возвращает queryset списка покупок для текущего пользователя."""
        return self.request.user.list.all()

    @action(detail=True, methods=['POST'],
            permission_classes=[IsAuthenticated])
    def add_to_shopping_list(self, request, pk=None):
        """Добавляет рецепт в список покупок."""
        return self.add_obj(ShoppingList, request.user, pk)

    @action(detail=True, methods=['DELETE'],
            permission_classes=[AllowAny])
    def remove_from_shopping_list(self, request, pk=None):
        """Удаляет рецепт из списка покупок."""
        return self.delete_obj(ShoppingList, request.user, pk)

    def add_obj(self, model, user, pk):
        """Добавляет рецепт в модель (список покупок)."""
        if model.objects.filter(user=user, recipe__id=pk).exists():
            return Response({
                'errors': 'Мы проверили, рецепт уже в списоке покупок!'
            }, status=status.HTTP_400_BAD_REQUEST)
        recipe = get_object_or_404(Recipe, id=pk)
        model.objects.create(user=user, recipe=recipe)
        serializer = ShoppingListSerializer(recipe)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def delete_obj(self, model, user, pk):
        """Удаляет рецепт из модели (список покупок)."""
        obj = model.objects.filter(user=user, recipe__id=pk)
        if obj.exists():
            obj.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        return Response({
            'errors': 'Ой! Рецепт не найден в списке покупок!'
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['post', ])
def logout(request):
    if request.method == 'POST':
        try:
            token = Token.objects.get(user=request.user.id)
            if token:
                token.delete()
                return Response(
                    None,
                    status=status.HTTP_204_NO_CONTENT
                )
        except Token.DoesNotExist:
            return Response({'detail': 'Ой! Кажется, '
                             'токен уже удален или не существует!'})


@api_view(['post', ])
def password_change(request):
    if request.method == 'POST':
        serializer = UserPasswordSerializer(data=request.data)
        if serializer.is_valid():
            if request.user.check_password(
                serializer.data.get('current_password')
            ):
                user = User.objects.get(id=request.user.id)
                user.set_password(serializer.data.get('new_password'))
                user.save()
                return Response(status=status.HTTP_204_NO_CONTENT)
            return Response({'detail': 'О, нет! Неверный пароль!'})
        return Response(serializer.errors)
