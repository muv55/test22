from django.db import models
from django.contrib.auth.models import AbstractUser

from foodgram.settings import MAX_LEN_CHAR, MAX_LEN_EMAIL


class User(AbstractUser):
    """Модель пользователя"""

    first_name = models.CharField(
        'Имя',
        max_length=MAX_LEN_CHAR
    )
    last_name = models.CharField(
        'Фамилия',
        max_length=MAX_LEN_CHAR
    )
    email = models.EmailField(
        'Email', max_length=MAX_LEN_EMAIL,
        unique=True,
    )
    username = models.CharField(
        'Имя пользователя',
        max_length=MAX_LEN_CHAR,
        unique=True,
    )
    password = models.CharField(
        'Пароль', max_length=MAX_LEN_CHAR,
    )

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'
        constraints = [
            models.UniqueConstraint(
                fields=['username', 'email'],
                name='unique_username_email'
            )
        ]

    def __str__(self):
        return self.username


class Subscribe(models.Model):
    """Модель подписки на автора"""

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='follower',
        verbose_name='Подписчик',
    )
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='follow',
        verbose_name='Автор',
    )

    class Meta:
        verbose_name = 'Подписка на автора'
        verbose_name_plural = 'Подписки на авторов'
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'author'],
                name='unique_user_author'
            )
        ]

    def __str__(self):
        return f'Вы {self.user.username} подписаны на {self.author.username}'
