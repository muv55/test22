from django.db import models
from django.contrib.auth import get_user_model

from foodgram.settings import MAX_LEN_CHAR, MAX_LEN_NAME

User = get_user_model()


class Tag(models.Model):
    """Модель для хранения информации о тегах."""
    name = models.CharField('Название тега', max_length=MAX_LEN_CHAR)
    color = models.CharField('Цветовой HEX-код', max_length=7)
    slug = models.SlugField('Slug')

    class Meta:
        verbose_name = 'Тег'
        verbose_name_plural = 'Теги'

    def __str__(self):
        return self.name


class Ingredient(models.Model):
    """Модель для хранения информации об ингредиентах."""
    name = models.CharField(
        'Название ингредиента',
        max_length=MAX_LEN_CHAR,
        unique=True
    )
    measurement_unit = models.CharField(
        'Единица измерения',
        max_length=32
    )

    class Meta:
        ordering = ('name',)
        verbose_name = 'Ингредиент'
        verbose_name_plural = 'Ингредиенты'

    def __str__(self):
        return f'{self.name} {self.measurement_unit}'


class Recipe(models.Model):
    """Модель для хранения информации о рецептах."""
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='recipes',
        verbose_name='Автор',
    )
    title = models.CharField(
        'Название',
        max_length=MAX_LEN_NAME
    )
    image = models.ImageField(
        'Картинка',
        upload_to='recipes/images/',
        default=None,
        null=True,
    )
    description = models.TextField(
        'Описание рецепта'
    )
    ingredients = models.ManyToManyField(
        Ingredient,
        through='RecipeIngredient',
        blank=True,
        related_name='recipe',
        verbose_name='Ингредиенты',
    )
    tags = models.ManyToManyField(
        Tag,
        verbose_name='Теги',
        blank=True,
        related_name='recipe',
    )
    cooking_time = models.PositiveSmallIntegerField(
        'Время приготовления в минутах'
    )
    pub_date = models.DateTimeField(
        'Дата публикации рецепта',
        auto_now_add=True,
    )

    class Meta:
        ordering = ('-pub_date',)
        verbose_name = 'Рецепт'
        verbose_name_plural = 'Рецепты'

    def __str__(self):
        return self.title


class RecipeIngredient(models.Model):
    """Модель для связи рецептов и ингредиентов с указанием количества."""
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        related_name='recipe_ingredients',
        verbose_name='Рецепт',
    )
    ingredient = models.ForeignKey(
        Ingredient,
        on_delete=models.CASCADE,
        related_name='ingredients_recipe',
        verbose_name='Ингредиент',
    )
    amount = models.PositiveSmallIntegerField(
        'Количество'
    )

    class Meta:
        verbose_name = 'Количество ингредиента'
        verbose_name_plural = 'Количество ингредиентов'
        constraints = [
            models.UniqueConstraint(
                fields=['ingredient', 'recipe'],
                name='unique_ingredient_recipe',
            ),
        ]

    def __str__(self):
        return f'{self.ingredient.name} - {self.amount}'


class Favorite(models.Model):
    """Модель для хранения информации об избранных рецептах пользователей."""
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='favorites',
        verbose_name='В избранном',
    )
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        related_name='favorited_by',
        verbose_name='Рецепт',
    )

    class Meta:
        ordering = ('-id',)
        verbose_name = 'Избранное'
        verbose_name_plural = 'Избранные'
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'recipe'],
                name='unique_user_recipe',
            ),
        ]

    def __str__(self):
        return (
            f'Вы {self.user.username} добавили '
            '{self.recipe.title} в избранное.'
        )


class ShoppingList(models.Model):
    """Модель для хранения информации о списке покупок пользователей."""
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='list',
        verbose_name='Пользователь',
    )
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        related_name='list',
        verbose_name='Рецепт для списка покупок',
    )

    class Meta:
        ordering = ('-id',)
        verbose_name = 'Список покупок'
        verbose_name_plural = 'Списки покупок'
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'recipe'],
                name='unique_user_shoppinglist_recipe',
            ),
        ]

    def __str__(self):
        return (
            f'Вы {self.user.username} добавили '
            f'{self.recipe.title} в список покупок.'
        )
