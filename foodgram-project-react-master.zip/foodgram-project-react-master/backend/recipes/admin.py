from django.contrib import admin
from django.db.models import Count

from recipes import models


class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'author')
    list_filter = ('title', 'author', 'tags')
    search_fields = ('title',)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.annotate(favorites_count=Count('favorited_by'))
        return queryset

    def favorites_count(self, obj):
        return obj.favorites_count

    favorites_count.short_description = 'Количество добавлений в избранное'


class IngredientAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)


class TagAdmin(admin.ModelAdmin):
    pass


class RecipeIngredientAdmin(admin.ModelAdmin):
    list_display = ('ingredient',)
    search_fields = ('recipe',)


class FavoriteAdmin(admin.ModelAdmin):
    list_display = ('user',)


class ShoppingListAdmin(admin.ModelAdmin):
    list_display = ('user', 'recipe',)


admin.site.register(models.Recipe, RecipeAdmin)
admin.site.register(models.Ingredient, IngredientAdmin)
admin.site.register(models.Tag, TagAdmin)
admin.site.register(models.RecipeIngredient, RecipeIngredientAdmin)
admin.site.register(models.Favorite, FavoriteAdmin)
admin.site.register(models.ShoppingList, ShoppingListAdmin)
